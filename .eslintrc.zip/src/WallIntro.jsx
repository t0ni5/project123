import wall from "./assets/wallpic.png"

function Wallintro() {
    return (
        <img
            class="img-fluid wall"
            src = {wall}
            alt = "prison wall"
        />
    )
}

export default Wallintro